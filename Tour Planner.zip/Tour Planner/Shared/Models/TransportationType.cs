namespace Shared.Models;

public enum TransportationType
{
    Bike,
    Walk,
    Car
}