using Backend.DbContext;
using Backend.Repository;
using Microsoft.EntityFrameworkCore;

namespace UnitTests;

public class Tests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void FindTourById()
    {
        ToursDbContext _dbContext = new(new DbContextOptions<ToursDbContext>());
        TourRepository _repository = new(_dbContext);

        var result = _repository.ByIdAsync(1).Result.Id;

        Assert.Equals(result, 1);
    }
    
    [Test]
    public void FindTourByIdFail()
    {
        ToursDbContext _dbContext = new(new DbContextOptions<ToursDbContext>());
        TourRepository _repository = new(_dbContext);

        var result = _repository.ByIdAsync(1).Result.Id;

        Assert.That(1, Is.Not.EqualTo(result));
    }
    
    [Test]
    public void FindTourByIdFail()
    {
        ToursDbContext _dbContext = new(new DbContextOptions<ToursDbContext>());
        TourRepository _repository = new(_dbContext);

        var result = _repository.ByIdAsync(1).Result.Id;

        Assert.That(1, Is.Not.EqualTo(result));
    }
}